
export default function Home() {
  return (
    <main style={{fontFamily:'Arial',padding:'40px'}}>
      <h1>Nomad Atelier</h1>
      <p>Premium clothing for modern explorers.</p>
      <h2>Collections</h2>
      <ul>
        <li>Men's Collection</li>
        <li>Women's Collection</li>
        <li>Accessories</li>
      </ul>
      <h2>Contact</h2>
      <p>Email: hello@nomadatelier.com</p>
    </main>
  )
}
